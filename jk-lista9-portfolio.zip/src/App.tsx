import './index.css'

function App() {

  return (
    <>
      <h1>Hi app</h1>  
    </>
  )
}

export default App
